#include <iostream>
#include <limits>
#include "reactiontester.h"

int main()
{
    ReactionTester tester;
    tester.run();

    std::cout << "Programi kapatmak icin Enter'a basin...";
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::cin.get();

    return 0;
}
