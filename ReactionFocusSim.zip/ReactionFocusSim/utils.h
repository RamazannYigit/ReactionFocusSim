#ifndef UTILS_H
#define UTILS_H

namespace Utils {
    void waitRandomTime();
}

#endif // UTILS_H
