#include "utils.h"
#include <thread>
#include <chrono>
#include <cstdlib>
#include <ctime>

void Utils::waitRandomTime() {
    static bool seeded = false;
    if (!seeded) {
        std::srand(static_cast<unsigned>(std::time(nullptr)));
        seeded = true;
    }
    int waitTime = 1000 + std::rand() % 4000;
    std::this_thread::sleep_for(std::chrono::milliseconds(waitTime));
}
