#ifndef REACTIONTESTER_H
#define REACTIONTESTER_H

#include <vector>

class ReactionTester {
public:
    void run();


private:
    double measureReactionTime();
    std::vector<double> results;
};


#endif // REACTIONTESTER_H
