#include "reactiontester.h"
#include "utils.h"

#include <iostream>
#include <chrono>
#include <limits>
#include <thread>

void ReactionTester::run() {
    std::cout << "=== Reaksiyon ve Dikkat Testi ===\n";
    std::cout << "Baslamak icin 'hazir' yazin ve Enter'a basin:\n> ";

    std::string input;
    std::getline(std::cin, input);

    if (input != "hazir") {
        std::cout << "Hazir oldugunda tekrar deneyebilirsin. Cikis yapiliyor.\n";
        return;
    }

    results.clear();

    for (int i = 1; i <= 10; ++i) {
        std::cout << "\nTur " << i << ":\n";

        // Kullanıcının herhangi bir boş Enter bırakmaması için satırı temizle
        std::cout << "(Devam etmek icin Enter'a basin...)\n";
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        double rt = measureReactionTime();
        results.push_back(rt);
    }

    // Ortalama hesapla
    double sum = 0.0;
    for (auto r : results) sum += r;
    double average = sum / results.size();

    std::cout << "\nOrtalama tepki suresi: " << average << " saniye\n";
}

double ReactionTester::measureReactionTime() {
    std::cout << "Hazirlanma asamasindasiniz...\n";
    Utils::waitRandomTime();

    std::cout << "SIMDI BAS! (Enter)\n";

    auto start = std::chrono::high_resolution_clock::now();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Enter bekle
    auto end = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double> duration = end - start;
    std::cout << "Tepki suresi: " << duration.count() << " saniye\n";

    return duration.count();
}
